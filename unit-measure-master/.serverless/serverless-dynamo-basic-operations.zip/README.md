# serverless-dynamo-test
Serverless with dynamo integration example for azumher project, it was taken from FooBar!!! tutorial by Marcia Villalba
